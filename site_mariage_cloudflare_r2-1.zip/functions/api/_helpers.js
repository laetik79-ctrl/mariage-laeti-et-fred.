export function json(data,status=200){return Response.json(data,{status,headers:{'Cache-Control':'no-store'}})}
export function authorized(request,env,admin=false){const expected=admin?env.ADMIN_SECRET:env.INVITE_CODE;const supplied=request.headers.get(admin?'x-admin-secret':'x-guest-secret');return typeof expected==='string' && expected.length>0 && typeof supplied==='string' && supplied===expected;}
export function guard(context,admin=false){if(!authorized(context.request,context.env,admin))return json({error:'Code incorrect ou configuration incomplète.'},401);if(!context.env.MARIAGE_PHOTOS)return json({error:'Liaison R2 MARIAGE_PHOTOS absente.'},503);return null;}
export function safeId(id){return /^[a-z0-9-]{20,80}$/.test(id)}
